#!/usr/bin/env python3
from setuptools import setup, find_packages

setup(
    name = "driverMotors",
    version = "1.0",
    packages = find_packages(),
    description = "Driver Motors",
    autor = "Andres"
)
